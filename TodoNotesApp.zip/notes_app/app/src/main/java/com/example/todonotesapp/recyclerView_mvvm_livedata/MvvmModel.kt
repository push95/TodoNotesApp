package com.example.todonotesapp.recyclerView_mvvm_livedata

class MvvmModel(var title :String ,var description :String) {
}