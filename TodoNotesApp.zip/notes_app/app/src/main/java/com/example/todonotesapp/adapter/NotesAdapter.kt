package com.example.todonotesapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.todonotesapp.model.Notes
import com.example.todonotesapp.R

class NotesAdapter() : RecyclerView.Adapter<NotesAdapter.MyNotesViewHolder>() {

    private var notesList = ArrayList<Notes>()


    class MyNotesViewHolder(view: View?) : RecyclerView.ViewHolder(view!!) {
        val listTitle = itemView.findViewById<TextView>(R.id.titleTV)
        val listDescription = itemView.findViewById<TextView>(R.id.descTV)

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyNotesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list_notes, parent, false)
        return MyNotesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return notesList.size
    }

    override fun onBindViewHolder(holder: MyNotesViewHolder, position: Int) {
        holder.listTitle.text = notesList[position].title
        holder.listDescription.text = notesList[position].description
    }

    fun update(modelList: ArrayList<Notes>) {
        notesList = modelList
        notifyDataSetChanged()
    }
}