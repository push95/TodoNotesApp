package com.example.todonotesapp.model

import android.icu.text.CaseMap

class Notes(var title :String, var description: String){
}